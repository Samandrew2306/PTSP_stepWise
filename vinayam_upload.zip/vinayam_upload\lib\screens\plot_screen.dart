import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:provider/provider.dart';
import '../providers/theme_provider.dart';
import '../utils/distributions.dart';

class PlotScreen extends StatefulWidget {
  final String distribution;
  final double mean;
  final double variance;

  const PlotScreen({
    super.key,
    required this.distribution,
    required this.mean,
    required this.variance,
  });

  @override
  State<PlotScreen> createState() => _PlotScreenState();
}

class _PlotScreenState extends State<PlotScreen> {
  late PageController _pageController;
  int _currentPage = 0;
  late List<double> xPoints;
  late List<double> pdfPoints;
  late List<double> cdfPoints;

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
    _calculatePoints();
  }

  void _calculatePoints() {
    xPoints = Distributions.generateXPoints(
      widget.mean,
      widget.variance,
      widget.distribution,
    );
    pdfPoints = Distributions.calculatePDF(
      xPoints,
      widget.mean,
      widget.variance,
      widget.distribution,
    );
    cdfPoints = Distributions.calculateCDF(
      xPoints,
      widget.mean,
      widget.variance,
      widget.distribution,
    );
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final textColor = themeProvider.currentTheme.brightness == Brightness.dark
        ? Colors.white
        : Colors.black;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          '${widget.distribution.capitalize()} Distribution',
          style: themeProvider.getTextStyle(
            size: 20,
            weight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  'PDF',
                  style: themeProvider.getTextStyle(
                    size: 16,
                    weight: _currentPage == 0 ? FontWeight.bold : FontWeight.normal,
                    color: _currentPage == 0 ? textColor : Colors.grey,
                  ),
                ),
                const SizedBox(width: 40),
                Text(
                  'CDF',
                  style: themeProvider.getTextStyle(
                    size: 16,
                    weight: _currentPage == 1 ? FontWeight.bold : FontWeight.normal,
                    color: _currentPage == 1 ? textColor : Colors.grey,
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: PageView(
              controller: _pageController,
              onPageChanged: (index) {
                setState(() => _currentPage = index);
              },
              children: [
                _buildPlot(true),  // PDF
                _buildPlot(false), // CDF
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Text(
                  'Mean: ${widget.mean.toStringAsFixed(2)}',
                  style: themeProvider.getTextStyle(size: 16),
                ),
                const SizedBox(height: 8),
                Text(
                  'Variance: ${widget.variance.toStringAsFixed(2)}',
                  style: themeProvider.getTextStyle(size: 16),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPlot(bool isPDF) {
    final points = isPDF ? pdfPoints : cdfPoints;
    final maxY = isPDF ? points.reduce((a, b) => a > b ? a : b) : 1.0;
    
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: LineChart(
        LineChartData(
          gridData: const FlGridData(show: true),
          titlesData: FlTitlesData(
            bottomTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 30,
                interval: (xPoints.last - xPoints.first) / 5,
              ),
            ),
            leftTitles: AxisTitles(
              sideTitles: SideTitles(
                showTitles: true,
                reservedSize: 40,
                interval: maxY / 5,
              ),
            ),
            topTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
            rightTitles: const AxisTitles(
              sideTitles: SideTitles(showTitles: false),
            ),
          ),
          borderData: FlBorderData(show: true),
          minX: xPoints.first,
          maxX: xPoints.last,
          minY: 0,
          maxY: maxY,
          lineBarsData: [
            LineChartBarData(
              spots: List.generate(
                xPoints.length,
                (i) => FlSpot(xPoints[i], points[i]),
              ),
              isCurved: true,
              color: Colors.blue,
              dotData: const FlDotData(show: false),
              belowBarData: BarAreaData(
                show: true,
                color: Colors.blue.withOpacity(0.2),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

extension StringExtension on String {
  String capitalize() {
    return "${this[0].toUpperCase()}${substring(1)}";
  }
} 